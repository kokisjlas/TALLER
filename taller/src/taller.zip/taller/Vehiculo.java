package taller;

import java.util.Arrays;

public class Vehiculo {
	private String matricula;
	private TipoEstado estado;
	private int tipo; /*1-Coche o 2-Moto*/
	
	private Averia[] averias;
	private int indicador_averias=0;
	
	
	public Vehiculo(String matricula, int tipo) {
		this.matricula=matricula;
		this.tipo=tipo;
		this.estado=TipoEstado.EN_ESPERA;
	}
	
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public TipoEstado getEstado() {
		return estado;
	}

	public void setEstado(TipoEstado estado) {
		this.estado = estado;
	}

	public int getTipo() {
		return tipo;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public Averia[] getAverias() {
		return averias;
	}

	public void setAverias(Averia[] averias) {
		this.averias = averias;
	}

	public int  costeReparacion() {
		int costeTotal=0;
		for(int i=0;i<averias.length;i++) {
			costeTotal+= averias[i].getCostePorAveria();
		}
		return costeTotal;
	}
	public void altaAveria(Averia averia) {
		averias[indicador_averias]=averia;
		indicador_averias++;
	}

	@Override
	public String toString() {
		return "Vehiculo [matricula=" + matricula + ", estado=" + estado + ", tipo=" + tipo + ", averias="
				+ Arrays.toString(averias) + "]";
	}
	
	
	

}
