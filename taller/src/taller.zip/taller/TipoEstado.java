package taller;

public enum  TipoEstado {
	EN_REPARACION,EN_ESPERA,REPARADO;
	

}
